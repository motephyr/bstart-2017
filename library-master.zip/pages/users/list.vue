<template>
  <div>
    <h1>reading_activities</h1>
    <p>If you try to access this URL not connected, you will be redirected to the home page (server-side or client-side)</p>

    <table style="border: 1px solid black;">
      <thead>
      <tr>
        <th v-for="(value, key) in users[0]">{{(key != 'created_at' && key != 'updated_at') ? key : ''}}</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="user in users">
        <td>{{user._id}}</td>
        <td>{{user.name}}</td>
        <td>{{user.email}}</td>
        <td>{{user.accountLocked}}</td>
        <td>{{user.account}}</td>
        <td>{{user.phone}}</td>
        <td>{{user.mobile}}</td>
        <td>{{user.area}}</td>
        <td><button @click="edit_user(user._id)">Edit</button></td>
      </tr>
      </tbody>
    </table>
    <button @click="new_user">New User</button>


    <nuxt-link to="/">Back to the home page</nuxt-link>
  </div>
</template>

<script>
import axios from '~/plugins/axios'
export default {

  async asyncData ({ params, error }) {
    try {
      let users = await axios.get('/api/users')
      return {users: users.data}
    } catch (e) {
      error({ statusCode: 404, message: 'User not found' })
    }
  },
  data () {
    return {
      reading_activities_1: {
        xaxio: [],
        yaxio: [],
        value: []
      }
    }
  },
  methods: {
    new_user () {
      this.$router.replace('/users/new?' + Math.random())
    },
    edit_user (id) {
      this.$router.replace('/users/edit/'+ id +'?' + Math.random())
    }
  }
}
</script>
