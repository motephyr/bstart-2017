<template>
  <div class="nav-list">
    <!--<nuxt-link class="button" to="/" >Homepage</nuxt-link>-->
    <ul class="mlist">
      <nuxt-link class="button" to="/users/list" >帳號</nuxt-link>
      <nuxt-link class="button" to="/years/edit" >歷年計畫</nuxt-link>
    </ul>
    <ul class="mlist">
      <select v-model="$store.state.place" @change="getYearPlaceId()">
        　<option :value="p" v-for="(p, px) in $store.state.yearPlaces.places">{{p}}</option>
      </select>
      <select v-model="$store.state.year" @change="getYearPlaceId()">
        　<option :value="p" v-for="(p, px) in $store.state.yearPlaces.years">{{p}}</option>
      </select>

      <div id="app">
        <el-select v-model="value" placeholder="请选择">
          <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
          </el-option>
        </el-select>
      </div>


    </ul>
    <ul class="mlist">
      <nuxt-link class="button" to="/funding_implementations" >經費執行情形</nuxt-link>
      <nuxt-link class="button" to="/bookstarts" >嬰幼兒閱讀活動統計</nuxt-link>
      <nuxt-link class="button" to="/reading_activities" >多元閱讀活動統計</nuxt-link>
      <nuxt-link class="button" to="/promotion_activities" >本土語言閱讀活動統計</nuxt-link>
      <nuxt-link class="button" to="/" >活動表件</nuxt-link>
      <nuxt-link class="button" to="/" >領取禮袋資料</nuxt-link>
      <nuxt-link class="button" to="/" >活動剪影</nuxt-link>
      <nuxt-link class="button" to="/" >下載</nuxt-link>
    </ul>
  </div>
</template>

<script>
export default {
  computed: {
    place: {
      get: function () {
        return $store.state.place
      },
      set: function (val) {
        this.$store.dispatch('setPlace', val)
      }
    },
    year: {
      get: function () {
        return $store.state.year
      },
      set: function (val) {
        this.$store.dispatch('setYear', val)
      }
    }
  },
  methods: {
    getYearPlaceId () {
      this.$store.dispatch('getYearPlaceId', {
        place: this.$store.state.place,
        year: this.$store.state.year
      })
    }
  },
  data() {
    return {
      options: [{
        value: '选项1',
        label: '黄金糕'
      }, {
        value: '选项2',
        label: '双皮奶'
      }, {
        value: '选项3',
        label: '蚵仔煎'
      }, {
        value: '选项4',
        label: '龙须面'
      }, {
        value: '选项5',
        label: '北京烤鸭'
      }],
      value: ''
    }
  }
  // ,
  // data () {
  //   return {
  //     xaxio: ['一月', '二月', '二月', '二月', '二月', '二月', '二月', '二月', '二月', '二月', '二月', '十二月'],
  //     yaxio: ['經常門', '資本門']
  //   }
  // }
}
</script>

<style>
  .nav-list{
    background-color: #BDEEFF;
  }
</style>
