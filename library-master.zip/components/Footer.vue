<template>
  <footer>
    Visit our website for more documentation : <a href="https://nuxtjs.org" target="_blank">nuxtjs.org</a>
  </footer>
</template>
