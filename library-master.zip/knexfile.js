// Update with your config settings.

module.exports = {

  development: {
    client: "pg",
    connection: {
      host: "localhost",
      database: 'library_nuxt',
      user:     'postgres',
      password: '1234'
    },
    pool: {
      min: 2,
      max: 10
    },
    migrations: {
      tableName: 'knex_migrations'
    },
    url: 'postgres://postgres:1234@localhost:5432/',
    name: 'library_nuxt',
    collection: 'users'
  },

  staging: {
    client: 'pg',
    connection: {
      host: "localhost",
      database: 'library_nuxt',
      user:     'postgres',
      password: 'localhost'
    },
    pool: {
      min: 2,
      max: 10
    },
    migrations: {
      tableName: 'knex_migrations'
    }
  },

  production: {
    client: "pg",
    connection: {
      host: "gossim.chjvp9uqqlx5.ap-northeast-1.rds.amazonaws.com",
      database: 'library_nuxt',
      user:     'postgres',
      password: 'localhost'
    },
    url: 'postgres://postgres:localhost@gossim.chjvp9uqqlx5.ap-northeast-1.rds.amazonaws.com:5432/',
    name: 'library_nuxt',
    collection: 'users'
  },

  development_mysql: {
    client: "mysql",
    connection: {
      host     : 'localhost',
      user     : 'root',
      password : 'root',
      database : 'library_nuxt',
      charset  : 'utf8',
      port: 8889,
      socketPath: '/Applications/MAMP/tmp/mysql/mysql.sock'
    }
  }

}[process.env.NODE_ENV || 'development'];
