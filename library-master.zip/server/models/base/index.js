var Knexfile = require('../../../knexfile.js');
var Knex = require('knex')(Knexfile);

var Bookshelf = require('bookshelf')(Knex);

Bookshelf.Collection = Bookshelf.Collection.extend({
  limit: 10,
  currentpage: 1,
  pagination: {},
  base: '',
  paginationLimit: 10,
  queries: [],
  order: 'desc',
  /**
   * generates pagination data
   * @returns: {Object} - pagination data object
  */
  generatePagination: function(totalRecords) {
    var self = this;
    var totalpages = Math.ceil(totalRecords / self.limit);
    var groups = Math.ceil(totalpages / self.paginationLimit);
    var currentpage = self.currentpage;
    var items = [];
    var lastpage = totalpages;
    var next = currentpage < lastpage ? currentpage + 1 : 1;
    var prev = currentpage < 2 ? lastpage : currentpage - 1;
    var isFirstPage = currentpage === 1;
    var isLastPage = currentpage === lastpage;
    var highestF = currentpage + 2;
    var lowestF = currentpage - 2;
    var counterLimit = totalpages - 2;
    if (groups > 1) {
      items.push(1);
      items.push(2);
      // if our current page is higher than 3
      if (lowestF > 3) {
        items.push('...');
        //lets check if we our current page is towards the end
        if (lastpage - currentpage < 2) {
          lowestF -= 3; // add more previous links
        }
      } else {
        lowestF = 3; // lowest num to start looping from
      }
      for (var counter = lowestF; counter < lowestF + 5; counter++) {
        if (counter > counterLimit) {
          break;
        }
        items.push(counter);
      }
      // if current page not towards the end
      if (highestF < totalpages - 2) {
        items.push('...');
      }
      items.push(lastpage - 1);
      items.push(lastpage);
    } else {
      // no complex pagination required
      for (var counter2 = 1; counter2 <= lastpage; counter2++) {
        items.push(counter2);
      }
    }
    self.pagination = {
      items: items,
      current_page: currentpage,
      base: self.base,
      isFirstPage: isFirstPage,
      isLastPage: isLastPage,
      next: next,
      prev: prev,
      total: totalRecords,
      limit: self.limit,
      last_page: lastpage,
      from: (currentpage -1)*self.limit + 1,
      to: currentpage*self.limit
    };
    return self.pagination;
  },
  /**
   * Creates pagination data
   * @returns: {Promise} - resolves with pagination object
  */
  paginate: function() {
    var self = this;
    var query = self.model.forge().query();
    var totalpages = 0;
    if (self.queries.length > 0) {
      self.queries.forEach(function(where, i) {
        if (i === 0) {
          query.where(where[0], where[1], where[2]);
        } else {
          query.andWhere(where[0], where[1], where[2]);
        }
      });
    }
    return query.count('id AS total')
      .then(function(results) {
        totalpages = parseInt(results[0].total, 10);
        return self.generatePagination(totalpages);
      });
  },
  /**
   * fetches posts ordered by {sortColumn} and creates pagination
   * @returns: {Promise} - resolves with an Object
  */
  fetchBy: function(sortColumn, options, fetchOptions) {
    options = options || {};
    fetchOptions = fetchOptions || {};
    var self = this;
    var limit = parseInt(options.limit, 10) || self.limit;
    var currentpage = parseInt(options.page, 10) || self.currentpage;
    var order = options.order || self.order;
    self.queries = options.where || [];
    self.currentpage = currentpage;
    self.limit = limit;
    self.order = order;
    self.base = options.base || '';
    function fetch() {
      return self.constructor.forge()
        .query(function(query) {
          query.limit(limit);
          self.queries.forEach(function(where, i) {
            if (i === 0) {
              query.where(where[0], where[1], where[2]);
            } else {
              query.andWhere(where[0], where[1], where[2]);
            }
          });
          query.offset((currentpage - 1) * limit);
          query.orderBy(sortColumn, order);
        })
        .fetch(fetchOptions)
        .then(function(collection) {
          return {
            collection: collection,
            pagination: self.pagination
          };
        });
    }
    return self.paginate().then(fetch);
  }
});

Bookshelf.plugin('visibility');
Bookshelf.plugin('registry');
Bookshelf.plugin(require('bookshelf-modelbase').pluggable);
Bookshelf.plugin(require('bookshelf-cascade-delete'));
Bookshelf.plugin(require('bookshelf-upsert'));

module.exports = Bookshelf;
