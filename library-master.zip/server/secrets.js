/** Important **/
/** You should not be committing this file to GitHub **/
/** Repeat: DO! NOT! COMMIT! THIS! FILE! TO! YOUR! REPO! **/

module.exports = {
  // Find the appropriate database to connect to, default to localhost if not found.
  db: process.env.MONGOHQ_URL || process.env.MONGOLAB_URI || 'mongodb://localhost:27017/myproject',
  sessionSecret: process.env.SESSION_SECRET || 'Your Session Secret goes here',
  google: {
    clientID: process.env.GOOGLE_CLIENTID || '62351010161-eqcnoa340ki5ekb9gvids4ksgqt9hf48.apps.googleusercontent.com',
    clientSecret: process.env.GOOGLE_SECRET || '6cKCWD75gHgzCvM4VQyR5_TU',
    callbackURL: process.env.GOOGLE_CALLBACK || "/auth/google/callback"
  },
  facebook: {
    facebookAdmins: "1711272827",
    clientID: "714491012016792",
    clientSecret: "6783efd20a8380fadac29065010d5da4",
    callbackURL: "/auth/facebook/callback"
  },
  googlejwt: {
    "type": "service_account",
    "project_id": "focused-clock-137423",
    "private_key_id": "cce57fb9c6c3a5651dc2c0e468952d12632b2407",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIJQQIBADANBgkqhkiG9w0BAQEFAASCCSswggknAgEAAoICAQCcY9/DO5EBeuxd\n4w5NmzpX5puJe8Mu2rC6t2sOJGqKbSJQtk1pGfUUN+KLK6GDpJJNUc6mAfMEF4p8\nU47F4ldPxEq9KCmREK6F2QkJdCDzGXRaQOxVfoepE3+rXAoxhFkZyNKcoU5Jo8U3\nl6AhdPCWeIXBERQQnMgBzGTulIwgAd1zNgpfVKBoY9l9sLdAtL9zG2kKoEYlwAPc\n0SIchadydYrwKO9/Ukpo3vuoF2e6skkiYf9N/s3dO3oqwMYm3ePPK37c65cPmgo+\nbn9Nydu1309T2Nq3RufNM3YfEyp/ZHu8BG9mDEv1rB8tz+XbFf/fw63P8UQyufG6\nf9ZId1XVT1i4Yez/VX2vi0Mqh5+l1kgGEurMbFtqW+04IpbKd3MryF5zmPZALF+J\nc+iRnMXfc595yiJsdHHUXVgssgwH5h5AYU5VAe90VFzeshjfTahamOl5xL9AyiQ7\nuNCV+Gtaqo8rsb76GPPk/0CW8VBIsQVdB+0A5lEJhDBqMtn2qC9xQFcrwna9ZSMn\nsJwZC331TfDmFI2kmwy5kVOk1urgTbb2pFkHj5aFuQd85JS9o5NQLF8Yd/dsuuWR\ny6noAeOf9Yp5megwubGReGWMR4hToHz+i7pMxkDu950TIK+qKSUQtYMDHZwZ6WpG\nAAyxEIquGNcWKg4v8Rp0bXlZbU6G+wIDAQABAoICADAHYC4WOhdJSBQhakAdPxLF\nyNi1QKFAGmyNbfxe5LV0hMhi5G01wpWeAB4bnTPPs/q4+Az1pkuIa0h5ZOyS8ZuW\nvhlPn0xk4iRLHkJf/sqJ87jQHYS4IjOjwF7BGoRQkAiiK0RdKazl9eh30X7U6hpc\nEz/S3eWoMKiUvB6lUk92IyuB2jeixsyodZ/rSKw/llhkf6L6y/BGAymqtJ4r0dwO\nC0hsWfkxLZb9fC4IWhv1Kw67J+wtJ84cuQ0uPOys0ozKX+C7HZ52AVVhHAmox6gY\nV8V5YNpOlVvoxQsQGMoc8v8wIYImnqFpZf3szju1iuqOru+gugAWKQ3MuuNwetRX\n2jPcvwrIgn32Twr0z8e7PZgmFFzoDIGuqtWRBrM/RMaF+S1qNjsQWAa1ANP3+sN3\nyp20VUZSaxvGFUueM5VqxvXsi6V9wifxi1QIN0sopImFNBW5ukEKBhHbxUrZingQ\nEqnkqCHMi8cGppQ/krXKOlOJ22rXT1wQaVRviixFVhofuDKBpk9nKnuokDoOZinm\nwhgWkS7FmrbClKFLYrl8qBzJvA0M8lZV90PrfViHTEax6dgqhM1u6pVvnDk3ZM2Q\njRs79lY6gUc0vU3N8J5wK8/sdgzAP0JW5VwqRIZ4dKrmws/V6UYLA9zsJ4JCP9bI\nUkCgorm8Q4LOh167TL/ZAoIBAQDPZR8q0pgwsiiw4z5oKaKR8E6t8pThDGN2dND0\nj+r2eB+/KWhccx28vohIqsjTY1O7ss/lkr+EQE6Nd/JB6tPSW760cUxFPCzG2Rfl\n5kPJK8uUiApWq+g9GL0vUT7bGcxWS5KN0WEy8lHCIEkI9flRS47zchjQ00EkvHXZ\ndf3DUe6pfu7GPBsmZwiCkjX6eOIIqiNZsOXrd37PdJS4YgV134+OaWGRYPxHg+kq\ndCqIc5P2E2hmwzGnuGZqEstGQYyv7Yj8tws0TGWNtFudLDIXNyqpbKYPXKfoTpE8\nfzHxMFFP8U/mwtBBGRTL4ol9TN/KyTJiUpU6QqIHAQzrlKyXAoIBAQDBCql/G6FD\ne6gdyVyGTKFUH4FQ/m/VkjAavp96FZ+3n0fICaQUFRJM/klp7Xm2sOp+wB1VTgXz\ni7zfAspMhqgpOZz9XnBrTTykvJLE4UaklL+iISp3++7JePuh/iSlkB08TfO8QNn/\n5SpzySdHAoRtOCxtzs51SkCZFCr63bxh07XgHbhz61qnuImGVkVTywIWggJBC/eR\nqT61kR8AJenfVpBcjivC3nUZ/DuwCZp81emxk4mmhzlwDVQoF0lBT98UlaeNy2Cn\noQGpysl4opC3u6HKzGvO0QNg98yyqiHktPgHsS9vDb4Pa6LjV1c8uVWsdLm01xyA\nXQrPP6tle7E9AoIBAF+xWespVn2JhsrvX1kydMd/qN4MAvPAApiil9NwIEru7D8I\n/RVDLGJtS3a0Douy1ezSOajEyEdeYKBXytjtYCU8ncamTDnZ5RMvEh7K21YUNg/n\noVWSZkriglA13Zm80pKytgFnrcCTHHRE704KKKqBAYmEiLy57OHlbz8SeS9JO6TL\nY6LmEuTqP3v3uJ5Ebo7u6fa1b7Dw5vsT4Jce60QTDir4psMsi9r3m3syNHnXUlsF\nY3Oe9udbZy3kVBSrpB18rWtlje7onScAJBFmVgpuMuoPrqOB7ht7PPo7+jA+ShZn\n0qU4GF0hFH5qnWPKN6xanzvMvPwvyJEQxARjCisCggEACg8bK/NtoM2Vwg+XEax2\nj6Kgo27OtwtKFGqwdrUfwHq9S9Asy5sZfAeYHbvxJrLrVTV/kc1iBAHZEqnbjsdJ\nhfRpmM5N/1lj+pWU9Etk2fiiT7l4tA3dsIPsYNGUaUgsLdNGCx45/dqcLrJhqJKa\nAfL2ZbZsDbKT0SY64x2gzlww0v/Zd7jg3XKBQA3IyQgAENovceJEwUNXcDCis+hF\n2oxxM1F5OEtNQNBi79ZgRXcEGWu9tX7AYHVhWEF2YL/fuPvfYkUhwTpjksxtWSrn\nbZuKX73tNDax/WCMOxcgcwF3FzeFaD0IFVefgkcv1Ys2yqi+cIzxAENY59nCfaRH\nZQKCAQB9BRhnDZbH140t3hnzdqQHoRfk/Ujg/kutenoSbnizmafb8Hk77jzufNKc\nrxYfAwuXrTcKSmQw+TCF9j3cpDAWgM30OrPNVA9GM6Hgqr1UyuXlMnOlYtH4L39L\n+o/CaMlZ3Gsjp6LdHO03e0gF8IJ01sT5+cwRXPixDETQXU+UK93dCEnArm+XPfX2\nc+ke081tBEKpq4zYJ9krfPu/OXipN7qL+dFtn0Rgcyjvv2Em8S5F65WkOuaHIEWX\n0VpzUpacqAS9Nw+sdbe0YQ+MWwoyzpM3iShzn3Vc4KeBC+hv3/waDW7hB/RBQ0Tt\nkSq3tcPaZrCWAir52na0gesoF5DZ\n-----END PRIVATE KEY-----\n",
    "client_email": "no-reply-ses@focused-clock-137423.iam.gserviceaccount.com",
    "client_id": "114670101542433665116",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://accounts.google.com/o/oauth2/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/no-reply-ses%40focused-clock-137423.iam.gserviceaccount.com",
    "gmail":{
      "simAs":"hyl@gossim.io",
    "sendAs":"notification@gossim.io",
    "scopes":["https://www.googleapis.com/auth/gmail.settings.basic","https://www.googleapis.com/auth/gmail.settings.sharing", "https://www.googleapis.com/auth/gmail.send"]
    }
  },
  mailgun: {
    user: 'postmaster@console.gossim.io',
    pass: '6cd28c58315dd8c0d993a73d94734ee6'
  }
};
